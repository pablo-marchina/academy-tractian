#!/usr/bin/env python3
from __future__ import annotations

"""Execute the one authorized P12-C1 common-parent C0-vs-C1 cycle.

This runner is candidate-side only. It must run with the private oracle and all
blind partitions physically absent. It creates exactly 36 common parent outputs
from the activation mapping, freezes them in memory/on disk, applies C0/C1 to
the exact same parent for every ticket/repetition, then reapplies unchanged
E14q -> E14q2. No evaluator or private oracle code is invoked here.
"""

import argparse
import copy
import hashlib
import importlib.util
import json
import os
import time
from pathlib import Path
from typing import Any, Callable

HERE = Path(__file__).parent


def load_module(name: str, filename: str):
    path = HERE / filename
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"failed to load {filename}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# Load one deterministic post-model lineage and use references from that lineage
# so temporary canonicalization patches affect the same module instances.
e14e = load_module("p12_e14e", "e14e_dev_only_explicit_current_handoff_semantics.py")
e14d = e14e.e14d
e14c = e14d.e14c
e14 = e14c.e14
e11 = e14.e11
e10g = e11.e10g
e10e = e10g.e10e
e10d = e10e.e10d
e10c = e10d.e10c
e10b = e10c.e10b
base = e10b.base
capture = e10b.capture

# Independently pinned components that are called directly.
e14o = load_module("p12_e14o", "e14o_dev_only_public_factual_grounding_prompt.py")
e14f = load_module("p12_e14f", "e14f_dev_only_public_semantic_repair.py")
completeness = load_module("p12_completeness", "e14_completeness_capture.py")
transport = load_module("p12_transport", "e14_groq_rate_limit_transport.py")
e14n11 = load_module("p12_e14n11", "e14n_public_identifier_provenance_guard_v1_1.py")
e14p = load_module("p12_e14p", "e14p_public_epistemic_serialization_guard.py")
e14q = load_module("p12_e14q", "e14q_full_dev_public_action_authorization_consistency_guard.py")
e14q2 = load_module("p12_e14q2", "e14q2_full_dev_public_route_role_purpose_consistency_guard.py")
candidates = load_module("p12_candidates", "p12_c1_evidence_route_candidates.py")

PASS = "P12_C1_FIXED_CANDIDATE_OUTPUTS_PASS"
FAIL = "P12_C1_FIXED_CANDIDATE_OUTPUTS_NEEDS_REVIEW"
EXPECTED_ACTIVATION = "P12-C1-ACTIVATION-2026-08-23"
EXPECTED_STATUS = "ACTIVATION_ELIGIBILITY_PASS"
EXPECTED_SCOPE = "ONE_DETERMINISTIC_PAIRED_C0_VS_C1_EXPOSED_POOL_COMMON_PARENT_GENERATION_EVALUATION_CYCLE"
EXPECTED_SEEDS = [2026082301, 2026082302, 2026082303]
EXPECTED_CASES = 12
EXPECTED_PARENTS = 36


def stable_hash(value: Any) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def source_split_for_group(split_manifest: dict[str, Any], group_id: str) -> str:
    for split_name, split in split_manifest.get("splits", {}).items():
        for group in split.get("groups", []):
            if group.get("group_id") == group_id:
                return str(split_name)
    raise AssertionError(f"group absent from frozen split: {group_id}")


def exact_case_by_ticket(cases_payload: Any) -> dict[str, dict[str, Any]]:
    records = cases_payload.get("cases") if isinstance(cases_payload, dict) else cases_payload
    if not isinstance(records, list):
        raise AssertionError("agent-input cases must be a list or object with cases")
    out: dict[str, dict[str, Any]] = {}
    for record in records:
        if not isinstance(record, dict):
            continue
        ticket = str(record.get("ticket_id") or "")
        if not ticket:
            continue
        if ticket in out:
            raise AssertionError(f"duplicate visible ticket: {ticket}")
        out[ticket] = record
    return out


def assert_activation(activation: dict[str, Any]) -> None:
    if activation.get("activation_id") != EXPECTED_ACTIVATION:
        raise AssertionError("wrong activation id")
    if activation.get("status") != EXPECTED_STATUS or activation.get("activation_decision") != "PASS":
        raise AssertionError("activation has not passed")
    if activation.get("execution_authorized") is not True:
        raise AssertionError("execution is not authorized")
    if activation.get("authorized_scope") != EXPECTED_SCOPE:
        raise AssertionError("authorized scope changed")
    if activation.get("participating_arms") != ["C0", "C1"]:
        raise AssertionError("participating arm set changed")
    eligibility = activation.get("candidate_eligibility", {})
    if eligibility.get("C0", {}).get("eligible") is not True or eligibility.get("C1", {}).get("eligible") is not True:
        raise AssertionError("C0/C1 eligibility changed")
    if eligibility.get("C2", {}).get("eligible") is not False:
        raise AssertionError("C2 must remain ineligible in this cycle")
    rep = activation.get("repetition_policy", {})
    if rep.get("seeds") != EXPECTED_SEEDS or rep.get("expected_common_parent_generations") != EXPECTED_PARENTS:
        raise AssertionError("repetition schedule changed")
    mapping = activation.get("exposed_pool_mapping")
    if not isinstance(mapping, list) or len(mapping) != EXPECTED_CASES:
        raise AssertionError("activation must contain exactly 12 mapped ticket cases")
    if len({str(x.get("ticket_id")) for x in mapping}) != EXPECTED_CASES:
        raise AssertionError("activation ticket mapping must be unique")
    if len({str(x.get("group_id")) for x in mapping}) != 7:
        raise AssertionError("activation must contain exactly 7 exposed groups")
    if len({str(x.get("scenario_id")) for x in mapping}) != 11:
        raise AssertionError("activation must contain exactly 11 scenarios")


def assert_no_private_files() -> None:
    forbidden = [
        Path("eval/expected-paths.json"),
        Path("private-eval/expected-paths.json"),
        Path("docs/test-scenarios.md"),
        Path("eval/test-scenarios.md"),
    ]
    present = [str(path) for path in forbidden if path.exists()]
    if present:
        raise AssertionError(f"candidate-side private/semantic files still present: {present}")


def low_level_model_call(prompt: str, timeout: int, dry_run: bool, packet: dict[str, Any], repeat_index: int) -> tuple[str, dict[str, Any]]:
    if dry_run:
        return e10b.e10b_dry_output(packet, repeat_index)
    original = capture.base.SYSTEM_PROMPT
    capture.base.SYSTEM_PROMPT = e14o.effective_system_prompt()
    try:
        return transport.call_groq(prompt, timeout, capture.base)
    finally:
        capture.base.SYSTEM_PROMPT = original


model_call_with_repair = e14f.make_semantic_repair_call_model(low_level_model_call)


def _canonical_refined_e10d_reason(output: dict[str, Any]) -> str | None:
    # Mirrors E14e -> E14d -> E14c composition: refine the E10d handoff
    # fallback, then evaluate it against E14c's canonical public endpoint view.
    return e14e.refined_visible_guard_reason(e14c._canonicalized_guard_view(output))


def apply_upstream_deterministic_stack(output: dict[str, Any], visible_case: dict[str, Any], group_id: str) -> tuple[dict[str, Any], dict[str, Any]]:
    old_reason = e10d.visible_guard_reason
    old_evidence_count = e10e.evidence_marker_count
    old_e10e_norm = e10e.normalize_endpoint
    old_e10g_norm = e10g.normalize_endpoint
    old_e11_norm = e11.normalize_endpoint
    try:
        e10d.visible_guard_reason = _canonical_refined_e10d_reason
        e10e.evidence_marker_count = e14d.evidence_norm.public_evidence_family_count
        e10e.normalize_endpoint = e14c._canonical_normalize
        e10g.normalize_endpoint = e14c._canonical_normalize
        e11.normalize_endpoint = e14c._canonical_normalize

        current, m10d = e10d.apply_visible_escalation_guard_to_output(output)
        current, m10e = e10e.apply_premature_action_guard_to_output(current)
        current, m10g = e10g.apply_balanced_guard_to_output(current)
        call = {"group_id": group_id, "parsed_output": current}
        current, m11 = e11.apply_authorization_to_output(call)
        current, m14 = e14.policy.apply({"group_id": group_id, "parsed_output": current})
        if not isinstance(current, dict):
            raise AssertionError("E14 selective boundary removed parsed output")
    finally:
        e10d.visible_guard_reason = old_reason
        e10e.evidence_marker_count = old_evidence_count
        e10e.normalize_endpoint = old_e10e_norm
        e10g.normalize_endpoint = old_e10g_norm
        e11.normalize_endpoint = old_e11_norm

    old_sanitize = e14n11.parent._sanitize_text
    e14n11.parent._sanitize_text = e14n11._sanitize_text_v1_1
    try:
        current, mn = e14n11.parent.sanitize_output(current, visible_case)
    finally:
        e14n11.parent._sanitize_text = old_sanitize

    before_semantics = (
        current.get("decision_class"),
        current.get("should_take_action_now"),
        current.get("requires_human_escalation"),
        copy.deepcopy(current.get("action_escalation_rubric")),
    )
    current, mp = e14p.serialize_output(current)
    after_semantics = (
        current.get("decision_class"),
        current.get("should_take_action_now"),
        current.get("requires_human_escalation"),
        copy.deepcopy(current.get("action_escalation_rubric")),
    )
    if before_semantics != after_semantics:
        raise AssertionError("E14p changed decision/action/escalation semantics")
    if int(mp.get("evidence_public_signature_loss", 0)) or int(mp.get("evidence_public_signature_gain", 0)) or int(mp.get("evidence_public_signature_order_changed", 0)):
        raise AssertionError("E14p changed public evidence signatures")

    return current, {
        "e10d_applied": bool(m10d.get("applied")),
        "e10e_applied": bool(m10e.get("applied")),
        "e10g_applied": bool(m10g.get("applied")),
        "e11_applied": bool(m11.get("applied")),
        "e14_applied": bool(m14.get("applied")),
        "e14n_replacements": int(mn.get("unsupported_identifier_replacements", 0)),
        "e14p_changed_text_fields": int(mp.get("changed_text_fields", 0)),
    }


def reapply_q_stack(output: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    before_plan = copy.deepcopy(output.get("evidence_plan"))
    q_out, q_meta = e14q.transform_output(output)
    q2_out, q2_meta = e14q2.transform_output(q_out)
    if q2_out.get("evidence_plan") != before_plan:
        raise AssertionError("E14q/E14q2 changed candidate evidence_plan")
    return q2_out, {
        "e14q_applied": bool(q_meta.get("applied")),
        "e14q2_applied": bool(q2_meta.get("applied")),
    }


def generate_one(*, mapping: dict[str, Any], visible_case: dict[str, Any], source_split: str, seed: int, repeat_index: int, timeout: int, dry_run: bool, is_first_call: bool) -> dict[str, Any]:
    # Generic EXPOSED_POOL label prevents historical DEV/VALIDATION role from
    # becoming a candidate feature. Historical source split remains metadata only.
    packet = e10b.e10b_observation_packet("EXPOSED_POOL", str(mapping["group_id"]), {str(mapping["group_id"]): visible_case})
    prompt = e10b.e10b_build_prompt(packet, repeat_index)
    delay = float(os.getenv("E8_BETWEEN_CALL_DELAY_SECONDS", "0"))
    if not is_first_call and delay > 0:
        time.sleep(delay)

    max_retries = int(os.getenv("E14_MAX_RETRIES", "2"))
    parsed: dict[str, Any] | None = None
    provider_meta: dict[str, Any] = {}
    error_category: str | None = None
    retry_count = 0
    syntax_repair_count = 0
    semantic_repair_count = 0
    for attempt in range(max_retries + 1):
        if attempt > 0:
            retry_count += 1
            if delay > 0:
                time.sleep(delay)
        try:
            raw, provider_meta = model_call_with_repair(prompt, timeout, dry_run, packet, repeat_index)
            repair_meta = provider_meta.get("e14f_semantic_repair", {}) if isinstance(provider_meta, dict) else {}
            semantic_repair_count += int(repair_meta.get("repair_call_count") or 0)
            parsed, method = completeness.parse_with_repair(raw)
            if method:
                syntax_repair_count += 1
            if isinstance(parsed, dict):
                error_category = None
                break
            error_category = "parse_failure"
        except Exception as exc:  # provider text is intentionally not persisted
            error_category = str(getattr(exc, "category", "provider_failure"))
        if attempt >= max_retries:
            break

    if not isinstance(parsed, dict):
        return {
            "call_id": f"{mapping['ticket_id']}::seed-{seed}",
            "group_id": mapping["group_id"],
            "scenario_id": mapping["scenario_id"],
            "ticket_id": mapping["ticket_id"],
            "modality": mapping["modality"],
            "source_split": source_split,
            "partition": "EXPOSED_POOL",
            "seed": seed,
            "repeat_index": repeat_index,
            "success": False,
            "error_category": error_category or "unknown_failure",
            "retry_count": retry_count,
            "syntax_repair_count": syntax_repair_count,
            "semantic_repair_count": semantic_repair_count,
            "provider_attempts": int(provider_meta.get("provider_attempts") or provider_meta.get("transport", {}).get("provider_attempts") or 0) if isinstance(provider_meta, dict) else 0,
        }

    proxy = capture.score_output(parsed, "")
    if proxy.get("schema_valid") is not True or proxy.get("no_locked_test_claim") is not True:
        return {
            "call_id": f"{mapping['ticket_id']}::seed-{seed}",
            "group_id": mapping["group_id"],
            "scenario_id": mapping["scenario_id"],
            "ticket_id": mapping["ticket_id"],
            "modality": mapping["modality"],
            "source_split": source_split,
            "partition": "EXPOSED_POOL",
            "seed": seed,
            "repeat_index": repeat_index,
            "success": False,
            "error_category": "parent_proxy_schema_or_leakage_gate_failed",
            "retry_count": retry_count,
            "syntax_repair_count": syntax_repair_count,
            "semantic_repair_count": semantic_repair_count,
        }

    parent, guard_meta = apply_upstream_deterministic_stack(parsed, visible_case, str(mapping["group_id"]))
    return {
        "call_id": f"{mapping['ticket_id']}::seed-{seed}",
        "group_id": mapping["group_id"],
        "scenario_id": mapping["scenario_id"],
        "ticket_id": mapping["ticket_id"],
        "modality": mapping["modality"],
        "source_split": source_split,
        "partition": "EXPOSED_POOL",
        "seed": seed,
        "repeat_index": repeat_index,
        "success": True,
        "error_category": None,
        "retry_count": retry_count,
        "syntax_repair_count": syntax_repair_count,
        "semantic_repair_count": semantic_repair_count,
        "packet_hash": stable_hash(packet),
        "prompt_hash": stable_hash(prompt),
        "parent_hash": stable_hash(parent),
        "provider_model": str(provider_meta.get("model") or os.getenv("E8_GROQ_MODEL", "")),
        "provider_attempts": int(provider_meta.get("provider_attempts") or 0),
        "rate_limit_events": int(provider_meta.get("rate_limit_events") or 0),
        "upstream_guard_meta": guard_meta,
        "visible_case": visible_case,
        "parent_output": parent,
    }


def run(args: argparse.Namespace) -> int:
    activation = load_json(args.activation)
    split_manifest = load_json(args.split_manifest)
    cases_payload = load_json(args.agent_input_cases)
    assert_activation(activation)
    assert_no_private_files()

    if os.getenv("GITHUB_ACTIONS") == "true" and os.getenv("GITHUB_RUN_ATTEMPT") not in {None, "1"}:
        raise AssertionError("P12-C1 provider cycle may not be rerun with github.run_attempt > 1")

    if not args.dry_run:
        e14o.e14l.assert_frozen_configuration(dry_run=False)
        e14o.e14l.schema.run_self_checks()
        base.assert_zero_cost_guard("groq", False)
        if not os.getenv("GROQ_API_KEY"):
            raise AssertionError("GROQ_API_KEY is required for the authorized real cycle")

    case_by_ticket = exact_case_by_ticket(cases_payload)
    mapping_rows = activation["exposed_pool_mapping"]
    common_records: list[dict[str, Any]] = []
    first_call = True
    for mapping in mapping_rows:
        ticket = str(mapping["ticket_id"])
        case = case_by_ticket.get(ticket)
        if not isinstance(case, dict):
            raise AssertionError(f"mapped public ticket absent from agent input: {ticket}")
        if str(case.get("asset_id")) != str(mapping["group_id"]):
            raise AssertionError(f"ticket/group mismatch for {ticket}")
        source_split = source_split_for_group(split_manifest, str(mapping["group_id"]))
        if source_split not in {"DEV", "VALIDATION"}:
            raise AssertionError("P12-C1 mapping reached a forbidden historical split")
        for repeat_index, seed in enumerate(EXPECTED_SEEDS):
            record = generate_one(
                mapping=mapping,
                visible_case=case,
                source_split=source_split,
                seed=seed,
                repeat_index=repeat_index,
                timeout=args.timeout_seconds,
                dry_run=args.dry_run,
                is_first_call=first_call,
            )
            first_call = False
            common_records.append(record)

    successful = [r for r in common_records if r.get("success") is True]
    complete = len(common_records) == EXPECTED_PARENTS and len(successful) == EXPECTED_PARENTS

    sanitized = {
        "schema_version": "p12-c1-common-parent-generation-summary-v1",
        "status": "PASS" if complete else "OPERATIONAL_FAILURE",
        "activation_id": activation["activation_id"],
        "expected_common_parent_generations": EXPECTED_PARENTS,
        "attempted_common_parent_generations": len(common_records),
        "successful_common_parent_generations": len(successful),
        "failed_common_parent_generations": len(common_records) - len(successful),
        "provider_or_model_cycle_consumed": not args.dry_run,
        "rerun_allowed": False if not args.dry_run else None,
        "candidate_private_oracle_accesses": 0,
        "fresh_blind_accesses": 0,
        "legacy_locked_test_accesses": 0,
        "c2_provider_calls": 0,
        "total_internal_retries": sum(int(r.get("retry_count") or 0) for r in common_records),
        "total_semantic_repair_calls": sum(int(r.get("semantic_repair_count") or 0) for r in common_records),
        "total_syntax_repairs": sum(int(r.get("syntax_repair_count") or 0) for r in common_records),
        "failure_category_counts": {},
        "raw_outputs_in_summary": False,
    }
    for record in common_records:
        if record.get("success") is not True:
            key = str(record.get("error_category") or "unknown_failure")
            sanitized["failure_category_counts"][key] = sanitized["failure_category_counts"].get(key, 0) + 1
    args.generation_summary.parent.mkdir(parents=True, exist_ok=True)
    args.generation_summary.write_text(json.dumps(sanitized, indent=2), encoding="utf-8")

    if not complete:
        # Never produce scoreable candidate outputs from an incomplete parent set.
        return 2

    # Freeze all 36 parents before any candidate transform.
    parent_freeze_hash = stable_hash([{"call_id": r["call_id"], "parent_hash": r["parent_hash"]} for r in common_records])
    c0_inputs = [{"visible_case": r["visible_case"], "output": r["parent_output"]} for r in common_records]
    c0_outputs, c0_meta = candidates.apply_c0_batch(c0_inputs)
    c1_pairs = [candidates.apply_c1(r["parent_output"]) for r in common_records]
    c1_outputs = [pair[0] for pair in c1_pairs]

    final_calls: list[dict[str, Any]] = []
    for idx, record in enumerate(common_records):
        for arm, selected_output in (("C0", c0_outputs[idx]), ("C1", c1_outputs[idx])):
            final_output, q_meta = reapply_q_stack(selected_output)
            final_calls.append({
                "arm": arm,
                "candidate_id": candidates.C0_ID if arm == "C0" else candidates.C1_ID,
                "call_id": record["call_id"],
                "group_id": record["group_id"],
                "scenario_id": record["scenario_id"],
                "ticket_id": record["ticket_id"],
                "modality": record["modality"],
                "source_split": record["source_split"],
                "partition": "EXPOSED_POOL",
                "seed": record["seed"],
                "repeat_index": record["repeat_index"],
                "common_parent_hash": record["parent_hash"],
                "parsed_output": final_output,
                "output_hash": stable_hash(final_output),
                "q_stack_meta": q_meta,
            })

    if len(final_calls) != EXPECTED_PARENTS * 2:
        raise AssertionError("expected exactly 72 fixed candidate outputs")
    paired: dict[str, set[str]] = {}
    for call in final_calls:
        paired.setdefault(str(call["call_id"]), set()).add(str(call["common_parent_hash"]))
    if len(paired) != EXPECTED_PARENTS or any(len(values) != 1 for values in paired.values()):
        raise AssertionError("C0/C1 pairing did not preserve one identical common parent per call")

    fixed = {
        "schema_version": "p12-c1-fixed-candidate-outputs-v1",
        "status": PASS,
        "activation_id": activation["activation_id"],
        "experiment_id": activation["experiment_id"],
        "partition": "EXPOSED_POOL",
        "participating_arms": ["C0", "C1"],
        "common_parent_count": EXPECTED_PARENTS,
        "fixed_candidate_output_count": len(final_calls),
        "common_parent_freeze_hash": parent_freeze_hash,
        "c0_policy_meta": c0_meta,
        "c1_policy_meta": {
            "candidate_id": candidates.C1_ID,
            "output_count": len(c1_outputs),
            "max_final_reads_per_output": candidates.MAX_FINAL_READS_PER_OUTPUT,
            "private_oracle_used": False,
        },
        "candidate_private_oracle_accesses": 0,
        "fresh_blind_accesses": 0,
        "legacy_locked_test_accesses": 0,
        "c2_calls": 0,
        "fixed_before_private_scoring": True,
        "calls": final_calls,
    }
    args.fixed_outputs.parent.mkdir(parents=True, exist_ok=True)
    args.fixed_outputs.write_text(json.dumps(fixed, indent=2), encoding="utf-8")

    # Update sanitized summary only after candidate fixing succeeds.
    sanitized.update({
        "status": "PASS",
        "common_parent_freeze_hash": parent_freeze_hash,
        "c0_global_addition_budget": int(c0_meta.get("global_addition_budget") or 0),
        "c0_additions_total": int(c0_meta.get("additions_total") or 0),
        "fixed_candidate_outputs": len(final_calls),
        "same_parent_hash_for_each_pair": True,
        "candidate_outputs_fixed_before_private_scoring": True,
    })
    args.generation_summary.write_text(json.dumps(sanitized, indent=2), encoding="utf-8")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--activation", type=Path, required=True)
    parser.add_argument("--split-manifest", type=Path, default=Path("research/frozen/benchmark-split-v1.json"))
    parser.add_argument("--agent-input-cases", type=Path, default=Path("agent-input/cases.json"))
    parser.add_argument("--fixed-outputs", type=Path, required=True)
    parser.add_argument("--generation-summary", type=Path, required=True)
    parser.add_argument("--timeout-seconds", type=int, default=90)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    rc = run(args)
    print(json.dumps(load_json(args.generation_summary), indent=2))
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
